package com.alibaba.market.advice;


public class MessageCode {
	String code;
	String message;
	String detailedMessage;

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

	public String getDetailedMessage() {
		return detailedMessage;
	}

	public void setDetailedMessage(String detailedMessage) {
		this.detailedMessage = detailedMessage;
	}

	public MessageCode(String code, String message, String detailedMessage) {
		super();
		this.code = code;
		this.message = message;
		this.detailedMessage = detailedMessage;
	}
	
	public final static MessageCode SOMETHING_WENT_WRONG_ERROR = new MessageCode("1001", "Internal Error",
			"Sorry!! Something went wrong.");
	public final static MessageCode PARAMTER_MISSING = new MessageCode("1002", "Parameter Missing",
			"Required Parameter Missing");
}