package com.alibaba.market.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.market.converter.ProductConverter;
import com.alibaba.market.entity.Product;
import com.alibaba.market.filter.MarketFilter;
import com.alibaba.market.repository.ProductRepository;

@Service
public class MarketService {
	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ProductRepository repository;

	@Autowired
	ProductConverter converter;

	
	/*
	 * This method search product based on the passed filter.
	 */
	public List<com.alibaba.market.domain.Product> findProducts(MarketFilter queryFilter) {
		List<Product> productEntities = null;
		
		
		/*
		 * if queryFilter is not null,
		 * then it will query based on the passed queryfilter
		 */
		if(queryFilter!=null) {
			
			logger.debug("Query Filter is not null");
			
			/*
			 * if brandName is not empty and the others are empty
			 * then it will pefrom group by on BrandName.
			 */
		if ((queryFilter.getBrandName() != null && !queryFilter.getBrandName().isEmpty())
				&& (queryFilter.getColor() == null || queryFilter.getColor().isEmpty())
				&& (queryFilter.getSellerName() == null || queryFilter.getSellerName().isEmpty())
				&& (queryFilter.getSize() == null || queryFilter.getSize().isEmpty())
				) {
			
			logger.debug("Query Filter Brand Name is "+queryFilter.getBrandName());
			productEntities = repository.findByBrandName(queryFilter.getBrandName());
		}

		/*
		 * if color is not empty and the others are empty
		 * then it will pefrom group by on color.
		 */
		
		else if ((queryFilter.getColor() != null && !queryFilter.getColor().isEmpty())
				&& (queryFilter.getBrandName() == null || queryFilter.getBrandName().isEmpty())
				&& (queryFilter.getSellerName() == null || queryFilter.getSellerName().isEmpty())
				&& (queryFilter.getSize() == null || queryFilter.getSize().isEmpty())
				) {
			logger.debug("Query Filter Color Name is "+queryFilter.getColor());
			productEntities = repository.findByColor(queryFilter.getColor());
		}
		
		
		/*
		 * if size is not empty and the others are empty
		 * then it will pefrom group by on size.
		 */
		else if ((queryFilter.getSize() != null && !queryFilter.getSize().isEmpty())
				&& (queryFilter.getBrandName() == null || queryFilter.getBrandName().isEmpty())
				&& (queryFilter.getSellerName() == null || queryFilter.getSellerName().isEmpty())
				&& (queryFilter.getColor() == null || queryFilter.getColor().isEmpty())
				) {
			
			logger.debug("Query Filter Size is "+queryFilter.getSize());
			productEntities = repository.findBySize(queryFilter.getSize());
		}
		/*
		 * if all filters are empty,
		 * then it will fetch all products.
		 */
		else {
			logger.debug("All Query Filters are Empty");
			productEntities = repository.findAll();
		}
		}
		else
			productEntities = repository.findAll();

		return converter.convertEntityToDomain(productEntities);

	}
	
	/*
	 * This method search product based on the passed unique number
	 */

	public com.alibaba.market.domain.Product findProductBySKU(String sku) {
		
		logger.debug("Service layer : Finding Product for SKU "+ sku);

		return converter.convertEntityToDomain(repository.findBySku(sku)).get(0);

	}
	
	/*
	 * This method fetch the number of products based on sellerName
	 */

	
	public Long findProductForSeller (String sellerName) {
		
		return	repository.findProductForSeller(sellerName);
	
		
	}

}
