package com.alibaba.market.advice;


public class RestErrorInfo {
	public final String detail;
	public final String message;
	public final String code;

	public RestErrorInfo(MessageCode ex) {
		this.message = ex.getMessage();
		this.detail = ex.getDetailedMessage();
		this.code = ex.getCode();
	}

	public RestErrorInfo(MessageCode ex, String detail) {
		this.message = ex.getMessage();
		this.detail = detail;
		this.code = ex.getCode();
	}
}