package com.alibaba.market.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.market.domain.Product;
import com.alibaba.market.filter.MarketFilter;
import com.alibaba.market.service.MarketService;


@RequestMapping(value = "/v1")
@RestController
public class MarketController {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	MarketService marketService;
	
	
	@GetMapping(value = "/market", produces = { "application/json"})
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List<Product> findProducts(@Valid MarketFilter queryFilter) {
		logger.debug("Find Product for MarketFilter "+ queryFilter);
		return	marketService.findProducts(queryFilter);

		
	}
	
	@GetMapping(value = "/market/product", produces = { "application/json"})
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody Product findProducts(@RequestParam(value = "sku", required = true) String sku) {
		logger.debug("Find Product for Sku "+ sku);
		return	marketService.findProductBySKU(sku);

		
	}
	@GetMapping(value = "/market/active/products", produces = { "application/json"})
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody Long findActiveProductsForSeller(@RequestParam(value = "sellerName", required = true) String sellerName) {
		logger.debug("Find Product for sellerName "+ sellerName);
		
		return	marketService.findProductForSeller(sellerName);
		

		
	}
	
	

}
