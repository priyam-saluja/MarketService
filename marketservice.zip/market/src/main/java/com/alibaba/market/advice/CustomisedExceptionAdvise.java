package com.alibaba.market.advice;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;

/*
 * This class to handle Customised/userDefined Exception thrown by service.
 */

@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CustomisedExceptionAdvise {
	Logger logger = LoggerFactory.getLogger(getClass());

	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public @ResponseBody RestErrorInfo handleInvalidToken(Exception ex, WebRequest request,
			HttpServletResponse response) {
		logger.error("Exception occured", ex.getStackTrace());
		return new RestErrorInfo(MessageCode.PARAMTER_MISSING);
	}

}
