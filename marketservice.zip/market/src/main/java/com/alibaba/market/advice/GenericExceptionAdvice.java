/*******************************************************************************
 * •	© 2019 Scientific Games Corporation. All Rights Reserved.
 * *
 * •	INTELLECTUAL PROPERTY
 * * Copyrightable material, trademarks, patents, Source Code and other forms of intellectual property *contained in the SOFTWARE and DOCUMENTATION are owned or controlled by Scientific Games *Corporation or one or more of its directly or indirectly wholly owned companies (collectively, “Scientific *Games”) or its licensors or third parties, where applicable. Duplication of these programs in whole or in *part without written authorization from Scientific Games is expressly prohibited. If You have any questions *regarding intellectual property owned by, or under license to or from, Scientific Games, please contact the *Scientific Games Legal Department.
 * *
 * *www.scientificgames.com
 * *www.sggaming.com
 ******************************************************************************/
package com.alibaba.market.advice;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;



/*
 * This class to handle Generic Exception thrown by the service.
 */
@ControllerAdvice
@Order(Ordered.LOWEST_PRECEDENCE)
public class GenericExceptionAdvice {

	Logger logger = LoggerFactory.getLogger(getClass());

	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(Exception.class)
	public @ResponseBody RestErrorInfo handleInvalidToken(Exception ex, WebRequest request,
			HttpServletResponse response) {
		logger.error("Exception occured", ex.getStackTrace());
		return new RestErrorInfo(MessageCode.SOMETHING_WENT_WRONG_ERROR);
	}

}
