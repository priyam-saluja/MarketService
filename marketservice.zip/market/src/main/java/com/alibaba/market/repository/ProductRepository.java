package com.alibaba.market.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.alibaba.market.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product,Long>{
	
	List<Product> findBySize(String size);
	List<Product>findByBrandName(String brand);
	
	
	@Query("select count(prod) from Product prod  where prod.seller.name = ?1")
	Long findProductForSeller(String sellerName);
	List<Product>findByColor(String color);
	List<Product> findBySku(String sku);

}
