package com.alibaba.market.converter;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.alibaba.market.domain.Product;

@Component
public class ProductConverter {
	
	public List<Product> convertEntityToDomain(List<com.alibaba.market.entity.Product> productEntities){
		Logger logger = LoggerFactory.getLogger(this.getClass());
		logger.debug("converting Entity to Domain Class");
		
		return	productEntities.stream().map(entity -> {
			return new Product(entity.getSku(), entity.getName(), entity.getColor(), entity.getSize(), entity.getBrand().getName(), entity.getPrice(), entity.getCategory().getName(), entity.getSeller().getName());
			
		}).collect(Collectors.toList());
		
	
		
	}

}
