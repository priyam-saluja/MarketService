package com.alibaba.market.filter;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MarketFilter {
	
	private String brandName;
	private String sellerName;
	private String color;
	private String size;
	
	
	@Override
	public String toString() {
		return "[brandName - "+brandName+"  sellerName - "+sellerName+"  color - "+color+"  size - "+size+"]";
	}

}
