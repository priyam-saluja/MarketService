INSERT INTO Product (id, name, color,size,sku,price,product_id) VALUES
  (1, 'abc-shirt', 'RED','M','123',1500,1),
  (2, 'abc-jeans', 'BLACK','L','456',1500,2);
  
  
 INSERT INTO Brand (id, name,product_id) VALUES
  (1, 'Adidas',1),
  (2, 'Reebok',2);
  
 INSERT INTO Category (id, name,product_id) VALUES
  (1, 'Shirt',1),
  (2, 'Jeans',2);
 
  INSERT INTO Seller (id, name,product_id) VALUES
  (1, 'Ram',1),
  (2, 'Shyam',2);
  
  