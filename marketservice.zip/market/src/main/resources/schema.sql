CREATE TABLE Product (
  id          INTEGER PRIMARY KEY,
  name VARCHAR(64) NOT NULL,
 color VARCHAR(64) NOT NULL,
 size VARCHAR(64) NOT NULL,
 sku VARCHAR(64) NOT NULL,
 price VARCHAR(64) NOT NULL,
 product_id   INTEGER NOT NULL);
  
CREATE TABLE Brand (
  id          INTEGER PRIMARY KEY,
  name VARCHAR(64) NOT NULL,
  product_id   INTEGER NOT NULL);
  
CREATE TABLE Category (
  id          INTEGER PRIMARY KEY,
  name VARCHAR(64) NOT NULL,
  product_id   INTEGER NOT NULL);
  
CREATE TABLE Seller (
  id          INTEGER PRIMARY KEY,
  name VARCHAR(64) NOT NULL,
  product_id   INTEGER NOT NULL);