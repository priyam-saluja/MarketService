package com.alibaba.market.service.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.alibaba.market.entity.Brand;
import com.alibaba.market.entity.Category;
import com.alibaba.market.entity.Product;
import com.alibaba.market.entity.Seller;

public class Util {
	
	static List<Product> productEntity = new ArrayList<>();
	public static List<Product> getMockedResultForProduct() {
		Product product1 = new Product();
		product1.setId(1l);
		product1.setName("abc-shirt");
		product1.setColor("RED");
		product1.setSize("M");
		product1.setSku("123");
		product1.setPrice(1500d);
		product1.setBrand(getBrand(1, "Adidas", product1));
		product1.setCategory(getCategory(1, "Shirt", product1));
		product1.setSeller(getSeller(1, "Ram", product1));
		
		
		
		Product product2 = new Product();
		product2.setId(1l);
		product2.setName("abc-jeans");
		product2.setColor("BLACK");
		product2.setSize("L");
		product2.setSku("456");
		product2.setPrice(1500d);
		product2.setBrand(getBrand(2, "Reebok", product2));
		product2.setCategory(getCategory(2, "Jeans", product2));
		product2.setSeller(getSeller(2, "Shyam", product2));
		
		productEntity.add(product1);
		productEntity.add(product2);
		return productEntity;
	}
	
	public static Brand getBrand (long id, String name, Product product) {
		Brand brand = new Brand();
		brand.setId(id);
		brand.setName(name);
		brand.setProduct(product);
		
		return brand;
		
	}
	
	public static Category getCategory(long id, String name, Product product) {
		Category category = new Category();
		category.setId(id);
		category.setName(name);
		category.setProduct(product);
		
		return category;
		
	}
	public static Seller getSeller(long id, String name, Product product) {
		Seller seller = new Seller();
		seller.setId(id);
		seller.setName(name);
		seller.setProduct(product);
		
		return seller;
		
	}
	
	
	public static List<Product> getProductsForBrandName(String name){
		
	return	productEntity.stream().filter(entity -> entity.getBrand().getName().equals(name)).collect(Collectors.toList());
		
	}
}
