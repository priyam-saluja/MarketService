package com.alibaba.market;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketApplicationTests {


	void contextLoads() {
	}

}
