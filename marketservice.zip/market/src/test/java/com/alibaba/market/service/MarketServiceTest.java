package com.alibaba.market.service;



import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import org.junit.runner.RunWith;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import static org.mockito.ArgumentMatchers.anyString;

import com.alibaba.market.domain.Product;
import com.alibaba.market.filter.MarketFilter;
import com.alibaba.market.repository.ProductRepository;
import com.alibaba.market.service.util.Util;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MarketServiceTest {
	
	@Autowired
	MarketService service;
	
	@MockBean
	ProductRepository repo;
	
	
	
	@Test
	public void testShouldReturnTwoProducts() {
		when(repo.findAll())
		.thenReturn(Util.getMockedResultForProduct());
		List<Product>	productDomain =service.findProducts(null);
		assertEquals(2, productDomain.size());
		
	}
	@Test
	public void testShouldReturnOneProducts() {
		when(repo.findByBrandName(anyString()))
		.thenReturn(Util.getProductsForBrandName("Adidas"));
		MarketFilter filter = new MarketFilter();
		filter.setBrandName("Adidas");
		List<Product>	productDomain =service.findProducts(filter);
		assertEquals(1, productDomain.size());
		
	}

}
